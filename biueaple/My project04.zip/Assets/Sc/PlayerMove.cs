using UnityEngine;

public class PlayerMove : MonoBehaviour
{
    public Unit unit;
    public Vector3 MousePosi;
    public Vector3 MouseWorldPosi;
    public Camera cam;
    public Vector3 MovePoint;
    public bool MoveStop;
    public bool RatateStop;
    // Start is called before the first frame update
    void Start()
    {
        MovePoint.y = 1.0f;
    }

    // Update is called once per frame
    void Update()
    {
        if (Input.GetMouseButtonDown(1))
        {
            MousePosi = Input.mousePosition;
            MousePosi.z = 10.0f;
            MouseWorldPosi = cam.ScreenToWorldPoint(MousePosi);
            MovePoint = MouseWorldPosi;
            MovePoint.y = 1.0f;
            if (!RatateStop)
            {
                transform.LookAt(MovePoint);
            }
        }
        if (!MoveStop)
        {
            transform.position = Vector3.MoveTowards(transform.position, MovePoint, unit.state.Speed * Time.deltaTime);
        }
    }

    public void LookPosi(Vector3 vec)
    {
        if (!RatateStop)
        {
            transform.LookAt(vec);
        }
    }
}
