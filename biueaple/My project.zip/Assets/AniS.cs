﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class AniS : MonoBehaviour
{
    Animator animator;
    bool QSkillF = false;

    public void QSkillUse(int p_val)
    {
        Debug.Log($"스킬 : {p_val} 사용");
        QSkillF = true;
        if(p_val == 3)
        {
            QSkillEnd(3);
        }
    }

    public void QSkillEnd(int p_val)
    {
        Debug.Log($"스킬 : {p_val} 종료");
        animator.SetTrigger("QStop");
        QSkillF = false;
    }


    // Start is called before the first frame update
    void Start()
    {
        animator = GetComponent<Animator>();
    }

    // Update is called once per frame
    void Update()
    {
        if(Input.GetKeyDown(KeyCode.Q))
        {
            if(!QSkillF)
                animator.SetTrigger("QStart");
            else if(QSkillF)
                animator.SetTrigger("QConti");
        }
    }
}
