﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class Chara : MonoBehaviour
{
    public ChamState State;
    public Camera cam;
    public GameObject HPObj;
    public Image HPbar;
    public GameObject PlayerObj;
    public int Qcount = 0;
    SkillTest Skill;

    void Start()
    {
        State.HP = 100.0f;
        Skill = GetComponent<SkillTest>();
    }

 
    void Update()
    {
        SetHPbar();

        if (Input.GetKeyDown(KeyCode.Q))
        {
            if (Qcount > 3)
            {
                Qcount = 1;
            }
            else
            {
                Qcount = 1;
            }
        }
        QSkill(Qcount);
    }

    public void QSkill(int count)
    {
        
        switch (count)
        {
            case 1:
                if (Skill.isCollision)
                {
                    if (Skill.isin)
                    {
                        Skill.target.GetComponent<EnemyHP>().State.HP -= 20;
                        break;
                    }
                    Skill.target.GetComponent<EnemyHP>().State.HP -= 10;
                }
                break;
        }
        
    }

    public void SetHPbar()
    {
        HPObj.transform.position = cam.WorldToScreenPoint(PlayerObj.transform.position + new Vector3(0.0f, 0, 1.0f));

        HPbar.rectTransform.sizeDelta = new Vector2(State.HP, 20);
    }
}
