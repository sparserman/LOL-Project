﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PlayerMove : MonoBehaviour
{
    public Camera cam;
    public GameObject player;
    public float moveSpeed = 10.0f;
    public float rotateSpeed = 10.0f;
    Ray ray;

    private Vector3 movePos = Vector3.zero;
    private Vector3 moveDir = Vector3.zero;

    public bool movestop = false;

    // Start is called before the first frame update
    void Start()
    {
        
    }

    
    void Update()
    {
        Move();
    }


    public void Move()
    {
        if (Input.GetMouseButtonDown(1))
        {
            ray = cam.ScreenPointToRay(Input.mousePosition);
            
            if (Physics.Raycast(ray, out RaycastHit raycastHit))
            {
                if(raycastHit.transform.CompareTag("Plane"))
                {
                    movePos = raycastHit.point + new Vector3(0, 1.0f, 0);
                    moveDir = movePos - transform.position;
                }
            }
        }
        // 보는 방향과 목표 방향을 이용해 회전하고자하는 방향을 구한다.  
        if(!movestop)
        {
            Vector3 newDir = Vector3.RotateTowards(transform.forward, moveDir, rotateSpeed * Time.deltaTime, 0.0f);

            transform.rotation = Quaternion.LookRotation(newDir);
            transform.position = Vector3.MoveTowards(transform.position, movePos, moveSpeed * Time.deltaTime);
        }
        
    }
}
