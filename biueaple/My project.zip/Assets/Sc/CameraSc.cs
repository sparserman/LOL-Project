﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class CameraSc : MonoBehaviour
{
    public GameObject player;
    Vector3 vec;
    float height = 0;
    float width = 0;

    [SerializeField]
    protected float m_CameraSpeed = 10f;

    // Start is called before the first frame update
    void Start()
    {
        vec.y = 14.0f;
        height = Screen.height; //768
        width = Screen.width;   //1024
    }

    // Update is called once per frame
    void Update()
    {
        if (Input.GetKeyDown(KeyCode.Space))
        {
            transform.position = player.transform.position + vec;
        }
        if (Input.GetKey(KeyCode.UpArrow) || Input.mousePosition.y >= height)
        {
            transform.position += new Vector3(0, 0, m_CameraSpeed * Time.deltaTime);
        }
        if (Input.GetKey(KeyCode.LeftArrow) || Input.mousePosition.x <= 0)
        {
            transform.position += new Vector3(-m_CameraSpeed * Time.deltaTime, 0, 0);
        }
        if (Input.GetKey(KeyCode.RightArrow) || Input.mousePosition.x >= width)
        {
            transform.position += new Vector3(m_CameraSpeed * Time.deltaTime, 0, 0);
        }
        if (Input.GetKey(KeyCode.DownArrow) || Input.mousePosition.y <= 0)
        {
            transform.position += new Vector3(0, 0, -m_CameraSpeed * Time.deltaTime);
        }
    }
}
