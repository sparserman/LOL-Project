﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class EnemyHP : MonoBehaviour
{
    public ChamState State;
    public GameObject EnemyObj;
    public GameObject HPObj;
    public Image HPbar;
    public Camera cam;

    void Start()
    {
        State.HP = 100.0f;
    }

    // Update is called once per frame
    void Update()
    {
        HPObj.transform.position = cam.WorldToScreenPoint(EnemyObj.transform.position + new Vector3(0.0f, 0, 1.0f));

        HPbar.rectTransform.sizeDelta = new Vector2(State.HP, 20);
    }
}
