﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class AniS : MonoBehaviour
{
    Animator animator;
    bool QSkillF = false;
    public SkillTest Skill;

    public void QSkillUse(int p_val)
    {
        switch(p_val)
        {
            case 1:
                Skill.QSkill1();
                break;
            case 2:
                Skill.QSkill2();
                break;
            case 3:
                Skill.QSkill3();
                QSkillEnd(3);
                break;
        }
        Debug.Log($"스킬 : {p_val} 사용");
    }

    public void QSkillEnd(int p_val)
    {
        Debug.Log($"스킬 : {p_val} 종료");
        animator.SetTrigger("QStop");
        QSkillF = false;
    }

    public void QSkillOn()
    {
        Debug.Log("스킬 사용");
        QSkillF = true;
    }


    // Start is called before the first frame update
    void Start()
    {
        animator = GetComponent<Animator>();
    }

    // Update is called once per frame
    void Update()
    {
        if(Input.GetKeyDown(KeyCode.Q))
        {
            if(!QSkillF)
            {
                animator.SetTrigger("QStart");
            }
            else if(QSkillF)
            {
                animator.SetTrigger("QConti");
            }
        }
        if (Input.GetKeyDown(KeyCode.W))
        {
            Skill.WSkill();
        }
        if (Input.GetKeyDown(KeyCode.E))
        {
            Skill.ESkill();
        }
        if (Input.GetKeyDown(KeyCode.R))
        {
            Skill.RSkill();
        }
    }
}
