﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEditor;  // OnDrawGizmos

public class SkillTest : MonoBehaviour
{
    public Transform target;    // 부채꼴에 포함되는지 판별할 타겟
    public float angleRange = 30f;
    public float radius = 3f;
    public float radius2 = 3f;
    Color _blue = new Color(0f, 0f, 1f, 0.2f);
    Color _red = new Color(1f, 0f, 0f, 0.2f);

    public bool isCollision = false;
    public bool isin = false;

    PlayerMove playermove;
    Chara chara;

    public GameObject WSkillObj;

    public Vector3 WSkillPosi;
    public bool WSkillOn;
    public Vector3 ESkillPosi;

    void Start()
    {
        chara = GetComponent<Chara>();
        playermove = GetComponent<PlayerMove>();
    }

    void Update()
    {
        if(WSkillOn)
        {
            StartCoroutine(WSKillC());
            WSkillOn = false;
        }
    }



    public void QSkill1()
    {
        Collider[] targets1 = Physics.OverlapBox(transform.position + (transform.forward * 3), new Vector3(1.0f,1.0f,5.0f), transform.rotation);
        Collider[] targets2 = Physics.OverlapBox(transform.position + (transform.forward * 5), new Vector3(1.0f, 1.0f, 1.0f), transform.rotation);
        bool b = false;

        _Editor_AddQSkill();
        if (targets1 != null)
        {
            for(int i = 0; i < targets1.Length;i++)
            {
                for(int j = 0; j < targets2.Length;j++)
                {
                    if( targets1[i] == targets2[j])
                    {
                        b = true;
                        break;
                    }
                }
                if (b)
                    continue;

                if (targets1[i].transform.CompareTag("Enemy"))
                {
                    targets1[i].GetComponent<EnemyHP>().State.HP -= chara.State.Damage;
                    Debug.Log($"대미지 : {chara.State.Damage}");
                }
            }
            for (int i = 0; i < targets2.Length; i++)
            {
                if (targets2[i].transform.CompareTag("Enemy"))
                {
                    targets2[i].GetComponent<EnemyHP>().State.HP -= chara.State.Damage * 1.6f;
                    Debug.Log($"대미지 : {chara.State.Damage * 1.6f}");
                }
            }
        }
    }
    public void QSkill2()
    {
        Collider[] targets1 = Physics.OverlapBox(transform.position + (transform.forward * 1.5f), new Vector3(3.0f, 1.0f, 3.0f), transform.rotation);
        Collider[] targets2 = Physics.OverlapBox(transform.position + (transform.forward * 3), new Vector3(3.0f, 1.0f, 1.0f), transform.rotation);
        bool b = false;
        _Editor_AddQSkill();
        if (targets1 != null)
        {
            for (int i = 0; i < targets1.Length; i++)
            {
                for (int j = 0; j < targets2.Length; j++)
                {
                    if (targets1[i] == targets2[j])
                    {
                        b = true;
                        break;
                    }
                }
                if (b)
                    continue;

                if (targets1[i].transform.CompareTag("Enemy"))
                {
                    targets1[i].GetComponent<EnemyHP>().State.HP -= chara.State.Damage * 1.25f;
                    Debug.Log($"대미지 : {chara.State.Damage * 1.25f}");
                }
            }
            for (int i = 0; i < targets2.Length; i++)
            {
                if (targets2[i].transform.CompareTag("Enemy"))
                {
                    targets2[i].GetComponent<EnemyHP>().State.HP -= chara.State.Damage * 1.25f * 1.6f;
                    Debug.Log($"대미지 : {chara.State.Damage * 1.25f * 1.6f}");
                }
            }
        }
    }

    public void QSkill3()
    {

        _Editor_AddQSkill();

        Vector3 interV = target.position - (transform.position + transform.forward);

        // target과 나 사이의 거리가 radius 보다 작다면
        if (interV.magnitude <= radius)
        {
            // '타겟-나 벡터'와 '내 정면 벡터'를 내적
            float dot = Vector3.Dot(interV.normalized, transform.forward);
            // 두 벡터 모두 단위 벡터이므로 내적 결과에 cos의 역을 취해서 theta를 구함
            float theta = Mathf.Acos(dot);
            // angleRange와 비교하기 위해 degree로 변환
            float degree = Mathf.Rad2Deg * theta;

            // 시야각 판별
            if (degree <= angleRange / 2f)
            {
                if (interV.magnitude <= radius2)
                {
                    isCollision = true;
                    isin = true;
                    target.GetComponent<EnemyHP>().State.HP -= chara.State.Damage * 1.5f * 1.6f;
                    Debug.Log($"대미지 : {chara.State.Damage * 1.5f * 1.6f}");
                    return;
                }
                isCollision = true;
                target.GetComponent<EnemyHP>().State.HP -= chara.State.Damage * 1.5f;
                Debug.Log($"대미지 : {chara.State.Damage * 1.5}");
                isin = false;
            }
            else
                isCollision = false;

        }
        else
            isCollision = false;
    }

    public void WSkill()
    {
        Instantiate(WSkillObj, transform.position + transform.forward,transform.rotation);
    }

    public void ESkill()
    {
        ESkillPosi = transform.forward * 10;
        playermove.movestop = true;
        StartCoroutine(ESKillC());
    }

    public void RSkill()
    {
        chara.State.Damage += 10.0f;
        Debug.Log("공격력 10 증가");
        StartCoroutine(RSkillC());
    }

    IEnumerator ESKillC()
    {
        int count = 0;
        while(true)
        {
            transform.position = Vector3.MoveTowards(transform.position, ESkillPosi, 50.0f * Time.deltaTime);
            yield return null;
            count++;
            if (count >= 5)
                break;
        }
        playermove.movePos = transform.position;
        playermove.movestop = false;
        yield break;
    }

    IEnumerator RSkillC()
    {
        yield return new WaitForSeconds(6.0f);
        chara.State.Damage -= 10.0f;
        Debug.Log("공격력 10 하락");
    }

    IEnumerator WSKillC()
    {

        Vector3 interV = target.position - WSkillPosi;

        yield return new WaitForSeconds(1.5f);
        if (interV.magnitude <= 4.0f)
        {
            int count = 0;
            target.GetComponent<EnemyHP>().State.Speed += 2.5f;
            while (true)
            {
                yield return null;
                target.position = Vector3.MoveTowards(target.position, WSkillPosi, 100.0f * Time.deltaTime);
                count++;
                if (count > 10)
                    break;
            }
            
        }
    }




    [Header("[참고용들]"), SerializeField]
    protected Mesh m_GizmoMesh = null;
    protected float m_DrawLifeSec = 0f;


    void _Editor_AddQSkill()
    {
        m_DrawLifeSec = Time.time + 1f;
    }
    void _Editor_CollisionDrawMesh()
    {
        if (m_DrawLifeSec > Time.time)
        {
            Gizmos.DrawWireMesh(m_GizmoMesh, transform.position + (transform.forward * 1.5f), transform.rotation);
        }

    }

    private void OnDrawGizmos()
    {
        _Editor_CollisionDrawMesh();
        //Physics.OverlapBox(transform.position + (transform.forward * 1.5f), new Vector3(3.0f, 1.0f, 3.0f), transform.rotation);

        //Vector3 forwardpos = transform.rotation * (transform.forward * 1.5f);



    }
}