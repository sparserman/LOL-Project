﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class Chara : MonoBehaviour
{
    public ChamState State;
    public Camera cam;
    public GameObject HPObj;
    public Image HPbar;
    public GameObject PlayerObj;
    public int Qcount = 0;
    SkillTest Skill;

    void Start()
    {
        State.HP = 100.0f;
        State.Speed = 10.0f;
        State.Damage = 10.0f;
        Skill = GetComponent<SkillTest>();
    }

 
    void Update()
    {
        SetHPbar();
    }

    public void SetHPbar()
    {
        HPObj.transform.position = cam.WorldToScreenPoint(PlayerObj.transform.position + new Vector3(0.0f, 0, 1.0f));

        HPbar.rectTransform.sizeDelta = new Vector2(State.HP, 20);
    }
}
