﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class WSkillObj : MonoBehaviour
{
    float ftime = 0f;
    public float WSpeed = 30.0f;
    public SkillTest skill;
    // Start is called before the first frame update
    void Start()
    {
        skill = FindObjectOfType<SkillTest>();
    }

    // Update is called once per frame
    void Update()
    {
        ftime += Time.deltaTime;
        if (ftime >= 0.3f)
            Destroy(this.gameObject);
        this.transform.position += this.transform.forward * Time.deltaTime * WSpeed;
    }

    void OnTriggerEnter(Collider other)
    {
        if(other.CompareTag("Enemy"))
        {
            Debug.Log("충돌");
            other.GetComponent<EnemyHP>().State.Speed -= 2.5f;
            skill.WSkillPosi = this.transform.position;
            skill.WSkillOn = true;
            Destroy(this.gameObject);
        }
    }
}
