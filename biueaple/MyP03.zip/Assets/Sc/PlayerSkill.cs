using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PlayerSkill : MonoBehaviour
{
    public PlayerMove playerMove;
    public GameObject SkillQ;
    public GameObject SkillW;
    public GameObject SkillE;
    public GameObject SkillR;
    public QSkill qSc;
    public float QSkillRange;
    public float QSkillSpeed;
    public bool QSkillOn;
    public Vector3 Qtarget;
    public float QCoolTime;
    public float QCool = 5.0f;
    public Camera cam;
    public Vector3 Wtarget;
    public float WDamage = 20.0f;
    public float WCoolTime;
    public float WCool = 5.0f; 
    public float ECoolTime;
    public float ECool = 5.0f;
    public float RCoolTime;
    public float RCool = 5.0f;

    public GameObject[] AllObj;
    public Vector3 Etarget;
    public bool ESkillOn;

    public bool RSkillOn;
    public GameObject Rtarget;
    public float RSkillSpeed;

    // Start is called before the first frame update
    void Start()
    {
        qSc.Damage = 10.0f;
    }

    // Update is called once per frame
    void Update()
    {
        if(QCoolTime >= 0)
        {
            QCoolTime -= Time.deltaTime;
        }
        if(WCoolTime >= 0)
        {
            WCoolTime -= Time.deltaTime;
        }
        if (ECoolTime >= 0)
        {
            ECoolTime -= Time.deltaTime;
        }
        if (RCoolTime >= 0)
        {
            RCoolTime -= Time.deltaTime;
        }

        if (Input.GetKeyDown(KeyCode.Q))
        {
            if(QCoolTime <= 0)
            {
                qSc.count = 2;
                QCoolTime += QCool;
                QSkillOn = true;
                SkillQ.transform.position = transform.position;
                Vector3 vec = Input.mousePosition;
                vec.z = 10.0f;
                Vector3 vec2 = cam.ScreenToWorldPoint(vec);
                vec2.y = 1.0f;
                transform.LookAt(vec2);
                playerMove.MovePoint = transform.position;
                Qtarget = transform.position + transform.forward * QSkillRange;
                SkillQ.SetActive(true);
            }
        }
        else if(Input.GetKeyDown(KeyCode.W))
        {
            if(WCoolTime <= 0)
            {
                WCoolTime += WCool;
                Vector3 vec = Input.mousePosition;
                vec.z = 10.0f;
                Vector3 vec2 = cam.ScreenToWorldPoint(vec);
                vec2.y = 1.0f;
                Wtarget = vec2;
                transform.LookAt(vec2);
                playerMove.MovePoint = transform.position;
                SkillW.transform.position = cam.WorldToScreenPoint(Wtarget);
                SkillW.SetActive(true);
                StartCoroutine(WSkillC());
            }
        }
        else if(Input.GetKeyDown(KeyCode.E))
        {
            if(ECoolTime <= 0)
            {
                ECoolTime += ECool;
                Vector3 vec = Input.mousePosition;
                vec.z = 10.0f;
                Vector3 vec2 = cam.ScreenToWorldPoint(vec);
                vec2.y = 1.0f;
                Etarget = vec2;
                SkillE.transform.position = cam.WorldToScreenPoint(Etarget);
                SkillE.SetActive(true);
                transform.LookAt(Etarget);
                ESkillOn = true;
                StartCoroutine(ESkill());
            }
        }
        else if(Input.GetKeyDown(KeyCode.R))
        {
            if (RCoolTime <= 0)
            {
                RaycastHit hit = new RaycastHit();
                Ray ray = cam.ScreenPointToRay(Input.mousePosition);
                if(Physics.Raycast(ray.origin, ray.direction, out hit))
                {
                    if(hit.transform.CompareTag("Unit"))
                    {
                        Rtarget = hit.transform.gameObject;
                        RCoolTime += RCool;
                        RSkillOn = true;
                        transform.LookAt(Rtarget.transform.position);
                        SkillR.transform.position = transform.position;
                        SkillR.SetActive(true);
                    }
                }
            }
        }

        if(QSkillOn)
        {
            SkillQ.transform.position = Vector3.MoveTowards(SkillQ.transform.position,
                Qtarget,
                QSkillSpeed * Time.deltaTime);
            float dist = Vector3.Distance(transform.position, SkillQ.transform.position);
            if(dist >= QSkillRange - 0.1f)
            {
                QSkillOn = false;
                SkillQ.SetActive(false);
            }
        }
        if (ESkillOn)
        {
            for (int i = 0; i < AllObj.Length; i++)
            {
                if (Vector3.Distance(AllObj[i].transform.position, Etarget) < 3.0f &&
                    Vector3.Distance(AllObj[i].transform.position, Etarget) > 2.0f)
                {
                    Debug.Log($"{AllObj[i].name} ����");
                }
            }
        }
        if (RSkillOn)
        {
            SkillR.transform.position = Vector3.MoveTowards(SkillR.transform.position,
                Rtarget.transform.position,
                RSkillSpeed * Time.deltaTime);
            if(Vector3.Distance(SkillR.transform.position,Rtarget.transform.position) <= 0.5f)
            {
                Rtarget.GetComponent<Unit>().state.HP -= 50;
                SkillR.SetActive(false);
                RSkillOn = false;
            }
        }
    }

    IEnumerator WSkillC()
    {
        yield return new WaitForSeconds(1.2f);
        Collider[] coll = Physics.OverlapSphere(Wtarget, 1.5f);
        for(int i = 0; i < coll.Length; i++)
        {
            if (coll[i].gameObject.CompareTag("Unit"))
            {
                coll[i].GetComponent<Unit>().state.HP -= WDamage;
            }
        }
        SkillW.SetActive(false);
        Debug.Log("W�ߵ�");
    }
    IEnumerator ESkill()
    {
        yield return new WaitForSeconds(3.0f);
        ESkillOn = false;
        SkillE.SetActive(false);
    }

    private void OnDrawGizmos()
    {

    }
}
