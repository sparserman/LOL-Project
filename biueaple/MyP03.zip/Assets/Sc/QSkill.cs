using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class QSkill : MonoBehaviour
{
    public float Damage;
    public int count = 2;
    public GameObject Chara;
    // Start is called before the first frame update
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        
    }

    private void OnCollisionEnter(Collision collision)
    {
        if(collision.gameObject == Chara)
        {
            return;
        }
        if(collision.transform.CompareTag("Unit"))
        {
            count--;
            collision.gameObject.GetComponent<Unit>().state.HP -= Damage;
            if (count <= 0)
                this.gameObject.SetActive(false);
        }
    }


}
