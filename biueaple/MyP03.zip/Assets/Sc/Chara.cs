using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Chara : MonoBehaviour
{
    Unit myChara;
    
    void Start()
    {
        myChara = GetComponent<Unit>();
        myChara.state.HP = 500;
        myChara.state.Power = 30;
        myChara.state.Name = "���̰�";
    }

    // Update is called once per frame
    void Update()
    {
       
    }
}
