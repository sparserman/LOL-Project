using UnityEngine;

public class PlayerMove : MonoBehaviour
{
    public Vector3 MousePosi;
    public Vector3 MouseWorldPosi;
    public Camera cam;
    public Vector3 MovePoint;
    public float MoveSpeed;
    public bool MoveStop;
    // Start is called before the first frame update
    void Start()
    {
        MovePoint.y = 1.0f;
    }

    // Update is called once per frame
    void Update()
    {
        if (Input.GetMouseButtonDown(1))
        {
            MousePosi = Input.mousePosition;
            MousePosi.z = 10.0f;
            MouseWorldPosi = cam.ScreenToWorldPoint(MousePosi);
            MovePoint = MouseWorldPosi;
            MovePoint.y = 1.0f;
            if (!MoveStop)
            {
                transform.LookAt(MovePoint);
            }
        }
        if (!MoveStop)
        {
            transform.position = Vector3.MoveTowards(transform.position, MovePoint, MoveSpeed * Time.deltaTime);
        }
    }
}
