using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public struct State
{
    public float HP;
    public float Power;
    public string Name;
}

public class Unit : MonoBehaviour
{
    public State state;
    public GameObject HP;
    public Image HPBar;
    public Camera cam;
    void Start()
    {
        state.HP = 100;
        state.Power = 10;
        state.Name = "Bot";
    }

    
    void Update()
    {
        HP.transform.position = cam.WorldToScreenPoint(transform.position);
        HPBar.rectTransform.sizeDelta = new Vector2(state.HP, 20);
    }
}
