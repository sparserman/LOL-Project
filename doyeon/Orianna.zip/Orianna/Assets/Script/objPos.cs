using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class objPos : MonoBehaviour
{
    [SerializeField] float objspeed = 10f;
    public GameObject ch;
    private Vector3 objPOS;
    private Vector3 objDir;
    private Vector3 mousePos;
    private bool Chsel = true;
    private int skillcode = 0;
  
    void Start()
    {
        objPOS = ch.transform.position + new Vector3(0.3f, 1.0f, 0.3f);
        transform.position = ch.transform.position + objPOS;
    }


    void Update()
    {
        if (Chsel)
        {
            transform.position = ch.transform.position + objPOS;
        }
       
        if(skillcode == 1)
        {
            skill_Q();
        }
    }

    void skill_Q()
    {
       if( Input.GetKeyDown(KeyCode.Q))
       {
        if (Input.GetMouseButtonDown(0))
            {
                CalMousePos();
                ObjMove();
             
            }
            Chsel = false;
            skillcode = 1;
        }
    }

    void CalMousePos()
    {
        mousePos = Input.mousePosition;

    }
    void ObjMove()
    {
        transform.position = Vector3.MoveTowards(transform.position, mousePos, Time.deltaTime * objspeed);
    }

}
